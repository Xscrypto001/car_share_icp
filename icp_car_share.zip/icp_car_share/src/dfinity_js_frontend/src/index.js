import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'; // Example: replace with your main component

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
